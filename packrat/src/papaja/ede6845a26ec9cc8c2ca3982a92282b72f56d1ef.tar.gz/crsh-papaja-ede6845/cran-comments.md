## Test environments
* local OS X install, R 3.1.2
* local Ubuntu 14.04, R 3.1.2
* win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs, or NOTEs. 

## Downstream dependencies
There are no downstream dependencies.
