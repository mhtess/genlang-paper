# langcog

[![Travis-CI Build Status](https://travis-ci.org/langcog/langcog.svg?branch=master)](https://travis-ci.org/langcog/langcog)

R package of useful things used by Language and Cognition Lab

Install by running
```
install.packages("devtools")
devtools::install_github("langcog/langcog")
```
